<?php

$MESS['CLOSE_TITLE']        = 'Report in progress!';
$MESS['CLOSE_BODY']         = 'This window can be closed. Do not run the app until a report is generated. Upon the formation of the document, you will receive a notification with a link to download.';
$MESS['CLOSE_FOOTER']       = 'Thanks for choosing Prime Lab!';