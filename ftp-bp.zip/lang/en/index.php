<?php

$MESS['TITLE']              = 'Set period and project';
$MESS['PROJECT']            = 'Project';
$MESS['SUBMIT']             = 'RUN';
$MESS['SELECT_ALL_TEXT']    = 'Select all';
$MESS['FILTER_PLACEHOLDER'] = 'Project';
$MESS['NON_SELECTED_TEXT']  = 'Project not selected';
$MESS['N_SELECTED_TEXT']    = 'selected';
$MESS['ALL_SELECTED_TEXT']  = 'All selected';
$MESS['CLOSE_TITLE']        = 'Report in progress!';
$MESS['CLOSE_BODY']         = 'This window can be closed. Do not run the app until a report is generated. Upon the formation of the document, you will receive a notification with a link to download.';
$MESS['CLOSE_FOOTER']       = 'Thanks for choosing Prime Lab';