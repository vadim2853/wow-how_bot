<?php

$MESS['TITLE']  = 'Sorry!';
$MESS['BODY']   = 'The application is currently running by another user. Try running it later.';
$MESS['FOOTER'] = 'Thanks for choosing Prime Lab!';