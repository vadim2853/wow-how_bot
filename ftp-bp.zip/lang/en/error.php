<?php

$MESS['TITLE']  = 'Sorry!';
$MESS['BODY']   = 'There are some problems with the application. Contact the technical specialists of Prime Lab.';
$MESS['FOOTER'] = 'Thanks for choosing Prime Lab!';