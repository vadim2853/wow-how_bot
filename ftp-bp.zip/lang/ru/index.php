<?php

$MESS['TITLE']              = 'Установите период и проект';
$MESS['PROJECT']            = 'Проект';
$MESS['SUBMIT']             = 'Сформировать';
$MESS['SELECT_ALL_TEXT']    = 'Выбрать все';
$MESS['FILTER_PLACEHOLDER'] = 'Проект';
$MESS['NON_SELECTED_TEXT']  = 'Проект не выбран';
$MESS['N_SELECTED_TEXT']    = 'выбрано';
$MESS['ALL_SELECTED_TEXT']  = 'Выбраны все';
$MESS['CLOSE_TITLE']        = 'Отчет формируется!';
$MESS['CLOSE_BODY']         = 'Это окно может быть закрыто. Не запускайте приложение пока не сформируется отчет. По факту формирования документа Вам прийдет уведомление с ссылкой на скачивание.';
$MESS['CLOSE_FOOTER']       = 'Благодарим что выбрали Prime Lab';