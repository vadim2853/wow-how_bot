<?php

$arDbInfo = array(
    'HOST'          => 'dev-pl.co.ua',
    'USER'          => 'vtrwkhhb_pl',
    'PASSWORD'      => 'Sdm0SuULgcXJ',
    'DATABASE'      => 'vtrwkhhb_primelab',
);

define('REPORTS_PATH', 'https://project-bot.wow-how.com/reports/');