<?php

$MESS['TITLE']              = 'Set period and project';
$MESS['PROJECT']            = 'Project';
$MESS['SUBMIT']             = 'RUN';
$MESS['SELECT_ALL_TEXT']    = 'Select all';
$MESS['FILTER_PLACEHOLDER'] = 'Project';
$MESS['NON_SELECTED_TEXT']  = 'Project not selected';
$MESS['N_SELECTED_TEXT']    = 'selected';
$MESS['ALL_SELECTED_TEXT']  = 'All selected';