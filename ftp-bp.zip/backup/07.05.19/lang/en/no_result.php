<?php

$MESS['TITLE']  = 'No data!';
$MESS['BODY']   = 'Select other search options.';
$MESS['BACK']   = 'BACK';