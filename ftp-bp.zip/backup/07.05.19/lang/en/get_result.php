<?

$MESS['BACK']                               = 'Back';

$MESS['DEAL_TITLE']                         = 'Deal';
$MESS['DEAL_TABLE_TITLE']                   = 'Deal title';
$MESS['DEAL_TABLE_DATE']                    = 'Deal creation date';
$MESS['DEAL_TABLE_CUSTOMER']                = 'Customer';
$MESS['DEAL_TABLE_STATUS']                  = 'Deal status';
$MESS['DEAL_TABLE_CREATOR']                 = 'Deal created by';
$MESS['DEAL_TABLE_RESPONSIBLE']             = 'Deal responsible';
$MESS['DEAL_TABLE_AMOUNT']                  = 'Amount of deal';
$MESS['DEAL_TABLE_HOURS']                   = 'Allotted time';
$MESS['DEAL_TABLE_HOUR_COST']               = 'Cost per hour';
$MESS['DEAL_EXPENSES']                      = 'Project expenses';

$MESS['INVOICES_TITLE']                     = 'Invoices';
$MESS['INVOICES_TABLE_DATE']                = 'Date of creation';
$MESS['INVOICES_TABLE_STATUS']              = 'Status';
$MESS['INVOICES_TABLE_AMOUNT']              = 'Amount';
$MESS['INVOICES_TABLE_CURRENCY']            = 'Currency';
$MESS['INVOICES_TOTAL_SUM']                 = 'Invoices total amount';
$MESS['INVOICES_PAID_TOTAL_SUM']            = 'Total amount of paid invoices';

$MESS['PROJECT_TITLE']                      = 'Project';
$MESS['PROJECT_TABLE_TOTAL_TIME']           = 'Total task time';
$MESS['PROJECT_TABLE_TOTAL_ELAPSED_TIME']   = 'Elapsed time';
$MESS['PROJECT_TABLE_PERIOD_ELAPSED_TIME']  = 'Elapsed time for the period';
$MESS['PROJECT_DATE']                       = 'Project creation date';