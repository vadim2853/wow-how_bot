<?php

$MESS['TITLE']              = 'Установите период и проект';
$MESS['PROJECT']            = 'Проект';
$MESS['SUBMIT']             = 'Сформировать';
$MESS['SELECT_ALL_TEXT']    = 'Выбрать все';
$MESS['FILTER_PLACEHOLDER'] = 'Проект';
$MESS['NON_SELECTED_TEXT']  = 'Проект не выбран';
$MESS['N_SELECTED_TEXT']    = 'выбрано';
$MESS['ALL_SELECTED_TEXT']  = 'Выбраны все';