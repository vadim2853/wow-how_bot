<?

$MESS['BACK']                               = 'Назад';

$MESS['DEAL_TITLE']                         = 'Сделка';
$MESS['DEAL_TABLE_TITLE']                   = 'Название сделки';
$MESS['DEAL_TABLE_DATE']                    = 'Дата создания сделки';
$MESS['DEAL_TABLE_CUSTOMER']                = 'Клиент';
$MESS['DEAL_TABLE_STATUS']                  = 'Статус сделки';
$MESS['DEAL_TABLE_CREATOR']                 = 'Кем создана сделка';
$MESS['DEAL_TABLE_RESPONSIBLE']             = 'Ответственный по сделке';
$MESS['DEAL_TABLE_AMOUNT']                  = 'Сумма сделки';
$MESS['DEAL_TABLE_HOURS']                   = 'Кол-во часов';
$MESS['DEAL_TABLE_HOUR_COST']               = 'Стоимость часа';
$MESS['DEAL_EXPENSES']                      = 'Затраты';

$MESS['INVOICES_TITLE']                     = 'Счета';
$MESS['INVOICES_TABLE_DATE']                = 'Дата создания';
$MESS['INVOICES_TABLE_STATUS']              = 'Статус';
$MESS['INVOICES_TABLE_AMOUNT']              = 'Сумма';
$MESS['INVOICES_TABLE_CURRENCY']            = 'Валюта';
$MESS['INVOICES_TOTAL_SUM']                 = 'Общая сумма счетов';
$MESS['INVOICES_PAID_TOTAL_SUM']            = 'Сумма оплаченных счетов';

$MESS['PROJECT_TITLE']                      = 'Проект';
$MESS['PROJECT_TABLE_TOTAL_TIME']           = 'Общее время задач';
$MESS['PROJECT_TABLE_TOTAL_ELAPSED_TIME']   = 'Общее затраченное время';
$MESS['PROJECT_TABLE_PERIOD_ELAPSED_TIME']  = 'Затраченное время за период';
$MESS['PROJECT_DATE']                       = 'Дата создания проекта';