<?php

$MESS['TITLE']              = 'Встановіть період і проект';
$MESS['PROJECT']            = 'Проект';
$MESS['SUBMIT']             = 'Сформувати';
$MESS['SELECT_ALL_TEXT']    = 'Обрати усі';
$MESS['FILTER_PLACEHOLDER'] = 'Проект';
$MESS['NON_SELECTED_TEXT']  = 'Проект не обрано';
$MESS['N_SELECTED_TEXT']    = 'обрано';
$MESS['ALL_SELECTED_TEXT']  = 'Обрані всі';