<?

$MESS['BACK']                               = 'Назад';

$MESS['DEAL_TITLE']                         = 'Угода';
$MESS['DEAL_TABLE_TITLE']                   = 'Назва угоди';
$MESS['DEAL_TABLE_DATE']                    = 'Дата створення угоди';
$MESS['DEAL_TABLE_CUSTOMER']                = 'Клієнт';
$MESS['DEAL_TABLE_STATUS']                  = 'Статус угоди';
$MESS['DEAL_TABLE_CREATOR']                 = 'Ким створена угода';
$MESS['DEAL_TABLE_RESPONSIBLE']             = 'Відповідальний за угоду';
$MESS['DEAL_TABLE_AMOUNT']                  = 'Сума угоди';
$MESS['DEAL_TABLE_HOURS']                   = 'Кіл-ть часів';
$MESS['DEAL_TABLE_HOUR_COST']               = 'Вартість часу';
$MESS['DEAL_EXPENSES']                      = 'Витрати';

$MESS['INVOICES_TITLE']                     = 'Рахунки';
$MESS['INVOICES_TABLE_DATE']                = 'Дата створення';
$MESS['INVOICES_TABLE_STATUS']              = 'Статус';
$MESS['INVOICES_TABLE_AMOUNT']              = 'Сума';
$MESS['INVOICES_TABLE_CURRENCY']            = 'Валюта';
$MESS['INVOICES_TOTAL_SUM']                 = 'Загальна сума рахунків';
$MESS['INVOICES_PAID_TOTAL_SUM']            = 'Сума сплачених рахунків';

$MESS['PROJECT_TITLE']                      = 'Проект';
$MESS['PROJECT_TABLE_TOTAL_TIME']           = 'Загальний час завдань';
$MESS['PROJECT_TABLE_TOTAL_ELAPSED_TIME']   = 'Загальний витрачений час';
$MESS['PROJECT_TABLE_PERIOD_ELAPSED_TIME']  = 'Витрачений час за період';
$MESS['PROJECT_DATE']                       = 'Дата створення проекту';