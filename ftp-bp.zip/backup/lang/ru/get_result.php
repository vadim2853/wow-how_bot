<?

$MESS['BACK']                               = 'Назад';

$MESS['DEAL_TITLE']                         = 'Сделка';
$MESS['DEAL_TABLE_TITLE']                   = 'Название';
$MESS['DEAL_TABLE_DATE']                    = 'Дата создания';
$MESS['DEAL_TABLE_CUSTOMER']                = 'Клиент';
$MESS['DEAL_TABLE_STATUS']                  = 'Статус';
$MESS['DEAL_TABLE_CREATOR']                 = 'Кем создана';
$MESS['DEAL_TABLE_RESPONSIBLE']             = 'Ответственный';
$MESS['DEAL_TABLE_AMOUNT']                  = 'Сумма';
$MESS['DEAL_TABLE_HOURS']                   = 'Кол-во часов';
$MESS['DEAL_TABLE_HOUR_COST']               = 'Стоимость часа';

$MESS['INVOICES_TITLE']                     = 'Счета';
$MESS['INVOICES_TABLE_DATE']                = 'Дата создания';
$MESS['INVOICES_TABLE_STATUS']              = 'Статус';
$MESS['INVOICES_TABLE_AMOUNT']              = 'Сумма';
$MESS['INVOICES_TABLE_CURRENCY']            = 'Валюта';

$MESS['PROJECT_TITLE']                      = 'Проект';
$MESS['PROJECT_TABLE_TOTAL_TIME']           = 'Общее время задач';
$MESS['PROJECT_TABLE_TOTAL_ELAPSED_TIME']   = 'Общее затраченное время';
$MESS['PROJECT_TABLE_PERIOD_ELAPSED_TIME']  = 'Затраченное время за период';