<?php

$MESS['TITLE']  = 'Установите период и проект';
$MESS['PROJECT']   = 'Проект';
$MESS['SUBMIT'] = 'Сформировать';