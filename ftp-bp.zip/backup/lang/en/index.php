<?php

$MESS['TITLE']  = 'Set period and project';
$MESS['PROJECT']   = 'Project';
$MESS['SUBMIT'] = 'RUN';