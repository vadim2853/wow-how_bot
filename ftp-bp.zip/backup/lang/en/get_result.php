<?

$MESS['BACK']                               = 'Back';

$MESS['DEAL_TITLE']                         = 'Deal';
$MESS['DEAL_TABLE_TITLE']                   = 'Title';
$MESS['DEAL_TABLE_DATE']                    = 'Date of creation';
$MESS['DEAL_TABLE_CUSTOMER']                = 'Customer';
$MESS['DEAL_TABLE_STATUS']                  = 'Status';
$MESS['DEAL_TABLE_CREATOR']                 = 'Created by';
$MESS['DEAL_TABLE_RESPONSIBLE']             = 'Responsible';
$MESS['DEAL_TABLE_AMOUNT']                  = 'Amount';
$MESS['DEAL_TABLE_HOURS']                   = 'Hours';
$MESS['DEAL_TABLE_HOUR_COST']               = 'Cost per hour';

$MESS['INVOICES_TITLE']                     = 'Invoices';
$MESS['INVOICES_TABLE_DATE']                = 'Date of creation';
$MESS['INVOICES_TABLE_STATUS']              = 'Status';
$MESS['INVOICES_TABLE_AMOUNT']              = 'Amount';
$MESS['INVOICES_TABLE_CURRENCY']            = 'Currency';

$MESS['PROJECT_TITLE']                      = 'Project';
$MESS['PROJECT_TABLE_TOTAL_TIME']           = 'Total task time';
$MESS['PROJECT_TABLE_TOTAL_ELAPSED_TIME']   = 'Elapsed time';
$MESS['PROJECT_TABLE_PERIOD_ELAPSED_TIME']  = 'Elapsed time for the period';