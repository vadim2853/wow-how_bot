<?php

$MESS['TITLE']  = 'Встановіть період і проект';
$MESS['PROJECT']   = 'Проект';
$MESS['SUBMIT'] = 'Сформувати';