<?

$MESS['BACK']                               = 'Назад';

$MESS['DEAL_TITLE']                         = 'Угода';
$MESS['DEAL_TABLE_TITLE']                   = 'Назва';
$MESS['DEAL_TABLE_DATE']                    = 'Дата створення';
$MESS['DEAL_TABLE_CUSTOMER']                = 'Клієнт';
$MESS['DEAL_TABLE_STATUS']                  = 'Статус';
$MESS['DEAL_TABLE_CREATOR']                 = 'Ким створена';
$MESS['DEAL_TABLE_RESPONSIBLE']             = 'Відповідальний';
$MESS['DEAL_TABLE_AMOUNT']                  = 'Сума';
$MESS['DEAL_TABLE_HOURS']                   = 'Кіл-ть часів';
$MESS['DEAL_TABLE_HOUR_COST']               = 'Вартість часу';

$MESS['INVOICES_TITLE']                     = 'Рахунки';
$MESS['INVOICES_TABLE_DATE']                = 'Дата створення';
$MESS['INVOICES_TABLE_STATUS']              = 'Статус';
$MESS['INVOICES_TABLE_AMOUNT']              = 'Сума';
$MESS['INVOICES_TABLE_CURRENCY']            = 'Валюта';

$MESS['PROJECT_TITLE']                      = 'Проект';
$MESS['PROJECT_TABLE_TOTAL_TIME']           = 'Загальний час завдань';
$MESS['PROJECT_TABLE_TOTAL_ELAPSED_TIME']   = 'Загальний витрачений час';
$MESS['PROJECT_TABLE_PERIOD_ELAPSED_TIME']  = 'Витрачений час за період';